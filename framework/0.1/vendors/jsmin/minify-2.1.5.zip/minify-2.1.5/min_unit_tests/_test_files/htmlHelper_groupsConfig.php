<?php

return array(
    'css' => array(
        '//_test_files/css/paths_prepend.css'
        ,'//_test_files/css/styles.css'
    )
);
