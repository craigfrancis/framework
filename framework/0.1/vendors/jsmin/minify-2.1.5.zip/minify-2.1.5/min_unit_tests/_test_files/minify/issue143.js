/*
 * This file is to intentionally throw a JSMin exception
 */
function HelloWorld() {
    return /regexp;
}
